# IoT Fountain
Source code for tutorial on Hackster.io
https://www.hackster.io/jhey/iot-fountain-882e3b

Water fountain controlled via the internet. Very simple Plug and Play components and node based programming!
